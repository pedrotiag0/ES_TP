from django.apps import AppConfig


class ProjetoesConfig(AppConfig):
    name = 'ProjetoES'
